from store.views.home import *
from store.views.login import *
from store.views.signup import *